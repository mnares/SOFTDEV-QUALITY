<?php
/**
* Community Builder (TM)
* @version $Id: $
* @package CommunityBuilder
* @copyright (C)2005-2016 www.joomlapolis.com / Lightning MultiCom SA - and its licensors, all rights reserved
* @license http://www.gnu.org/licenses/old-licenses/gpl-2.0.html GNU/GPL version 2
*/

use CB\Database\Table\PluginTable;

if ( ! ( defined( '_VALID_CB' ) || defined( '_JEXEC' ) || defined( '_VALID_MOS' ) ) ) { die( 'Direct Access to this location is not allowed.' ); }

/**
 * CB installer
 *
 * @return bool
 */
function plug_cbpackageinstaller_install()
{
	$installer		=	new packageinstallerInstaller( 'cb' );

	return $installer->install();
}

/**
 * Joomla installer
 *
 * Class com_packageinstallerInstallerScript
 */
class com_packageinstallerInstallerScript
{

	/**
	 * @return bool
	 */
	public function install()
	{
		$installer		=	new packageinstallerInstaller();

		return $installer->install();
	}

	/**
	 * @return bool
	 */
	public function discover_install()
	{
		return $this->install();
	}

	/**
	 * @return bool
	 */
	public function update()
	{
		return $this->install();
	}
}

class packageinstallerInstaller
{
	/** @var string  */
	private $location	=	'joomla';
	/** @var PluginTable  */
	private $plugin		=	null;

	/**
	 * com_packageinstallerInstallerScript constructor.
	 *
	 * @param string $location
	 */
	public function __construct( $location = 'joomla' )
	{
		if ( $location ) {
			$this->location		=	$location;
		}

		if ( $this->location == 'cb' ) {
			if ( ( ! file_exists( JPATH_SITE . '/libraries/CBLib/CBLib/Core/CBLib.php' ) ) || ( ! file_exists( JPATH_ADMINISTRATOR . '/components/com_comprofiler/plugin.foundation.php' ) ) ) {
				return;
			}

			include_once( JPATH_ADMINISTRATOR . '/components/com_comprofiler/plugin.foundation.php' );

			cbimport( 'cb.html' );

			static $plugin		=	null;

			if ( $plugin == null ) {
				$plugin			=	new PluginTable();

				$plugin->load( array( 'element' => 'cbpackageinstaller' ) );
			}

			$this->plugin		=	$plugin;
		}
	}

	/**
	 * @return bool
	 */
	public function install()
	{
		global $_CB_framework, $_PLUGINS;

		@set_time_limit( 300 );
		@ini_set( 'memory_limit', '128M' );
		@ini_set( 'post_max_size', '128M' );
		@ini_set( 'upload_max_filesize', '128M' );
		@ini_set( 'error_reporting', 0 );
		@ignore_user_abort( true );
		JFactory::getConfig()->set( 'debug', 0 );

		$packages					=	array(	'packages'		=>	array(),
												'libraries'		=>	array(),
												'components'	=>	array(),
												'plugins'		=>	array(),
												'modules'		=>	array(),
												'languages'		=>	array(),
												'templates'		=>	array(),
												'cb_plugins'	=>	array(),
												'queries'		=>	array(),
												'scripts'		=>	array(),
												'overrides'		=>	array(),
												'custom'		=>	array()
											);

		$count						=	0;

		foreach ( array_keys( $packages ) as $type ) {
			$this->directory_files( $type, $packages, $count );
		}

		$js							=	null;
		$plugin						=	null;

		if ( $this->plugin ) {
			$_CB_framework->document->addHeadStyleSheet( $_PLUGINS->getPluginLivePath( $this->plugin ) . '/cbpackageinstaller.css' );

			$return					=	'<div class="cb_packageinstaller">';
		} else {
			if ( $this->jVersion() == 5 ) {
				JHtml::_( 'jquery.framework' );
			}

			$return					=	'<div class="cb_packageinstaller">'
									.		'<link type="text/css" href="' . JURI::base() . 'components/com_packageinstaller/packageinstaller.css" rel="stylesheet" />';

			if ( $this->jVersion() < 5 ) {
				$return				.=		'<script type="text/javascript" src="https://code.jquery.com/jquery-2.2.4.min.js" integrity="sha256-BbhdlvQf/xTY9gja0Dq3HiwQF8LaCRTXxZKRutelT44=" crossorigin="anonymous"></script>'
									.		'<script type="text/javascript">jQuery.noConflict();</script>';
			}

			$js						=	"jQuery( document ).ready( function( $ ) {";
		}

		$return						.=		'<div class="packageinstaller-installer panel panel-default">'
									.			'<div class="panel-body">'
									.				'<div class="panel panel-default">'
									.					'<div id="packageinstaller-package" class="panel-heading text-center"></div>'
									.					'<div class="panel-body">'
									.						'<div id="packageinstaller-progress" class="progress progress-striped active">'
									.							'<div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%">'
									.								'<span class="sr-only">0% Complete</span>'
									.							'</div>'
									.						'</div>'
									.					'</div>'
									.				'</div>'
									.				'<div class="row">'
									.					'<div class="col-md-6">'
									.						'<div class="packageInstallerSuccess panel panel-default">'
									.							'<div class="panel-heading text-center">Success</div>'
									.							'<div id="packageinstaller-success" class="panel-body"></div>'
									.						'</div>'
									.					'</div>'
									.					'<div class="col-md-6">'
									.						'<div class="packageInstallerFailed panel panel-default">'
									.							'<div class="panel-heading text-center">Failed</div>'
									.							'<div id="packageinstaller-failed" class="panel-body"></div>'
									.						'</div>'
									.					'</div>'
									.				'</div>'
									.				'<div class="packageInstallerLog panel panel-default">'
									.					'<div class="panel-heading text-center">'
									.						'Log <small><a href="javascript: void(0);" id="packageinstaller-logshow">show</a><a href="javascript: void(0);" id="packageinstaller-loghide" style="display: none;">hide</a></small>'
									.					'</div>'
									.					'<div id="packageinstaller-log" class="panel-body" style="display: none;"></div>'
									.				'</div>'
									.			'</div>'
									.		'</div>';

		$js							.=		"$( '#packageinstaller-logshow' ).on( 'click', function() {"
									.			"$( '#packageinstaller-logshow' ).hide();"
									.			"$( '#packageinstaller-loghide,#packageinstaller-log' ).show();"
									.		"});"
									.		"$( '#packageinstaller-loghide' ).on( 'click', function() {"
									.			"$( '#packageinstaller-loghide,#packageinstaller-log' ).hide();"
									.			"$( '#packageinstaller-logshow' ).show();"
									.		"});"
									.		"$( '.cb_packageinstaller' ).on( 'click', '.packageInstallerAlertsShow', function() {"
									.			"$( this ).hide();"
									.			"$( this ).siblings( '.packageInstallerAlertsHide' ).show();"
									.			"$( this ).parent().siblings( '.packageInstallerAlerts' ).show();"
									.		"});"
									.		"$( '.cb_packageinstaller' ).on( 'click', '.packageInstallerAlertsHide', function() {"
									.			"$( this ).hide();"
									.			"$( this ).parent().siblings( '.packageInstallerAlerts' ).hide();"
									.			"$( this ).siblings( '.packageInstallerAlertsShow' ).show();"
									.		"});"
									.		"var packages = new Array();"
									.		"var packagesMessage = null;"
									.		"var packagesErrored = 0;";

		if ( $this->plugin ) {
			$uninstallUrl			=	$_CB_framework->backendViewUrl( 'editPlugin', false, array( 'action' => 'uninstallself', 'cid' => (int) $this->plugin->get( 'id' ) ), 'raw' );
		} else {
			$uninstallUrl			=	JRoute::_( 'index.php?option=com_packageinstaller&view=uninstallself&format=raw', false );
		}

		if ( $count ) {
			$pkgProgress			=	round( 90 / $count );
			$progress				=	0;
			$step					=	0;

			foreach ( $packages as $fld => $pkgs ) {
				if ( $pkgs ) {
					foreach ( $pkgs as $pkg ) {
						$progress	+=	$pkgProgress;
						$nextStep	=	( $step + 1 );

						if ( $this->plugin ) {
							$url	=	$_CB_framework->backendViewUrl( 'editPlugin', false, array( 'action' => 'installpkg', 'cid' => (int) $this->plugin->get( 'id' ), 'fld' => $fld, 'pkg' => $pkg ), 'raw' );
						} else {
							$url	=	JRoute::_( 'index.php?option=com_packageinstaller&view=installpkg&fld=' . urlencode( $fld ) . '&pkg=' . urlencode( $pkg ) . '&format=raw', false );
						}

						$js			.=		"packages[$step] = function() {"
									.			"$.ajax({"
									.				"url: '" . addslashes( $url ) . "',"
									.				"cache: false,"
									.				"type: 'GET',"
									.				"beforeSend: function( jqXHR, settings ) {"
									.					"$( '#packageinstaller-package' ).html( '" . addslashes( $pkg ) . " is being installed...' );"
									.					"$( '#packageinstaller-log' ).append( '<div>" . addslashes( $pkg ) . " is being installed.</div>' );"
									.					"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.install.begin', [$step, '" . addslashes( $pkg ) . "', jqXHR, settings] );"
									.				"},"
									.				"success: function( data, textStatus, jqXHR ) {"
									.					"if ( data.match( /^TRUE/i ) ) {"
									.						"reportInstallSuccess( '" . addslashes( $pkg ) . "', $progress, $nextStep, data.replace( /^TRUE:|TRUE/i, '' ) );"
									.						"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.install.success', [$step, '" . addslashes( $pkg ) . "', data, textStatus, jqXHR] );"
									.					"} else {"
									.						"reportInstallFailed( '" . addslashes( $pkg ) . "', $progress, $nextStep, data.replace( /^FALSE:|FALSE/i, '' ) );"
									.						"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.install.failed', [$step, '" . addslashes( $pkg ) . "', data, textStatus, jqXHR] );"
									.					"}"
									.				"},"
									.				"error: function( jqXHR, textStatus, errorThrown ) {"
									.					"reportInstallFailed( '" . addslashes( $pkg ) . "', $progress, $nextStep, jqXHR.status + ' - ' + errorThrown );"
									.					"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.install.failed', [$step, '" . addslashes( $pkg ) . "', jqXHR, textStatus, errorThrown] );"
									.				"}"
									.			"});"
									.		"};";

						$step		+=	1;
					}
				}
			}

			$js						.=		"packages[$step] = function() {"
									.			"$.ajax({"
									.				"url: '" . addslashes( $uninstallUrl ) . "',"
									.				"cache: false,"
									.				"type: 'GET',"
									.				"beforeSend: function( jqXHR, settings ) {"
									.					"$( '#packageinstaller-progress' ).find( '.progress-bar' ).attr( 'aria-valuenow', 90 ).css( 'width', '90%' );"
									.					"$( '#packageinstaller-progress' ).find( '.progress-bar' ).find( '.sr-only' ).html( '90% Complete' );"
									.					"$( '#packageinstaller-package' ).html( 'Now cleaning up...' );"
									.					"$( '#packageinstaller-log' ).append( '<div>Installer is cleaning up.</div>' );"
									.					"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.cleanup.begin', [jqXHR, settings] );"
									.				"},"
									.				"complete: function( jqXHR, textStatus ) {"
									.					"$( '#packageinstaller-progress' ).find( '.progress-bar' ).attr( 'aria-valuenow', 100 ).css( 'width', '100%' );"
									.					"$( '#packageinstaller-progress' ).find( '.progress-bar' ).find( '.sr-only' ).html( '100% Complete' );"
									.					"$( '#packageinstaller-progress' ).removeClass( 'progress-striped active' );"
									.					"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.install.done' );"
									.				"},"
									.				"success: function( data, textStatus, jqXHR ) {"
									.					"var msg = data.replace( /^TRUE|TRUE:|FALSE|FALSE:/i, '' );"
									.					"var messages = '';"
									.					"if ( ( typeof msg != 'undefined' ) && ( msg != '' ) ) {"
									.						"try {"
									.							"$.each( $.parseJSON( msg ), function() {"
									.								"if ( this.type == 'notice' ) {"
									.									"this.type = 'info';"
									.								"} else if ( this.type == 'message' ) {"
									.									"this.type = 'sccess';"
									.								"}"
									.								"messages += '<div class=\"alert alert-' + this.type + '\">' + this.message + '</div>';"
									.							"});"
									.						"} catch ( e ) {"
									.							"messages = msg;"
									.						"}"
									.					"}"
									.					"if ( data.match( /^TRUE/i ) ) {"
									.						"if ( packagesMessage && ( ! packagesErrored ) ) {"
									.							"$( '.cb_packageinstaller' ).hide();"
									.							"$( '.packageinstaller-installer' ).replaceWith( '<div class=\"packageinstaller-message\"><strong>' + $( packagesMessage ).html() + '</strong></div>' );"
									.							"$( '.cb_packageinstaller' ).fadeIn( 'slow' );"
									.						"}"
									.						"$( '#packageinstaller-package' ).html( ( packagesErrored ? ( packagesErrored == " . $count . " ? 'Package installation failed!' : 'Package installation partially complete!' ) : 'Package installation complete!' ) );"
									.						"$( '#packageinstaller-log' ).append( '<div class=\"text-success\">Installer cleaned up successfully.' + ( messages ? ' <small><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsShow\">show</a><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsHide\" style=\"display: none;\">hide</a></small><div class=\"packageInstallerAlerts\" style=\"display: none;\">' + messages + '</div>' : '' ) + '</div>' );"
									.						"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.cleanup.success', [data, textStatus, jqXHR] );"
									.					"} else {"
									.						"$( '#packageinstaller-package' ).html( 'The Package Installer failed to clean up. Please uninstall the Package Installer manually within " . ( $this->plugin ? 'Community Builder > Plugin Management' : 'Extensions > Manage' ) . ".' );"
									.						"$( '#packageinstaller-log' ).append( '<div class=\"text-danger\">Installer failed to clean up!' + ( messages ? ' <small><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsShow\">show</a><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsHide\" style=\"display: none;\">hide</a></small><div class=\"packageInstallerAlerts\" style=\"display: none;\">' + messages + '</div>' : '' ) + '</div>' );"
									.						"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.cleanup.failed', [data, textStatus, jqXHR] );"
									.					"}"
									.				"},"
									.				"error: function( jqXHR, textStatus, errorThrown ) {"
									.					"$( '#packageinstaller-package' ).html( 'The Package Installer failed to clean up. Please uninstall the Package Installer manually within " . ( $this->plugin ? 'Community Builder > Plugin Management' : 'Extensions > Manage' ) . ".' );"
									.					"$( '#packageinstaller-log' ).append( '<div class=\"text-danger\">Installer failed to clean up! Error: ' + jqXHR.status + ' - ' + errorThrown + '</div>' );"
									.					"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.cleanup.failed', [jqXHR, textStatus, errorThrown] );"
									.				"}"
									.			"});"
									.		"};"
									.		"function reportInstallSuccess( pkg, progress, nextstep, msg ) {"
									.			"var messages = '';"
									.			"if ( ( typeof msg != 'undefined' ) && ( msg != '' ) ) {"
									.				"try {"
									.					"$.each( $.parseJSON( msg ), function() {"
									.						"if ( this.type == 'notice' ) {"
									.							"this.type = 'info';"
									.						"} else if ( this.type == 'message' ) {"
									.							"this.type = 'sccess';"
									.						"}"
									.						"messages += '<div class=\"alert alert-' + this.type + '\">' + this.message + '</div>';"
									.					"});"
									.				"} catch ( e ) {"
									.					"messages = msg;"
									.				"}"
									.			"}"
									.			( $count == 1 ? "packagesMessage = messages;" : null )
									.			"$( '#packageinstaller-success' ).append( '<div>' + pkg + '</div>' );"
									.			"$( '#packageinstaller-log' ).append( '<div class=\"text-success\">' + pkg + ' installed successfully.' + ( messages ? ' <small><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsShow\">show</a><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsHide\" style=\"display: none;\">hide</a></small><div class=\"packageInstallerAlerts\" style=\"display: none;\">' + messages + '</div>' : '' ) + '</div>' );"
									.			"$( '#packageinstaller-progress' ).find( '.progress-bar' ).attr( 'aria-valuenow', progress ).css( 'width', progress + '%' );"
									.			"$( '#packageinstaller-progress' ).find( '.progress-bar' ).find( '.sr-only' ).html( progress + '% Complete' );"
									.			"beginInstallStep( nextstep );"
									.		"};"
									.		"function reportInstallFailed( pkg, progress, nextstep, error ) {"
									.			"packagesErrored++;"
									.			"var messages = '';"
									.			"if ( ( typeof error != 'undefined' ) && ( error != '' ) ) {"
									.				"try {"
									.					"$.each( $.parseJSON( error ), function() {"
									.						"if ( this.type == 'notice' ) {"
									.							"this.type = 'info';"
									.						"} else if ( this.type == 'message' ) {"
									.							"this.type = 'sccess';"
									.						"}"
									.						"messages += '<div class=\"alert alert-' + this.type + '\">' + this.message + '</div>';"
									.					"});"
									.				"} catch ( e ) {"
									.					"messages = error;"
									.				"}"
									.			"}"
									.			"$( '#packageinstaller-failed' ).append( '<div>' + pkg + '</div>' );"
									.			"$( '#packageinstaller-log' ).append( '<div class=\"text-danger\">' + pkg + ' failed to install!' + ( messages ? ' <small><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsShow\">show</a><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsHide\" style=\"display: none;\">hide</a></small><div class=\"packageInstallerAlerts\" style=\"display: none;\">' + messages + '</div>' : '' ) + '</div>' );"
									.			"$( '#packageinstaller-progress' ).find( '.progress-bar' ).attr( 'aria-valuenow', progress ).css( 'width', progress + '%' );"
									.			"$( '#packageinstaller-progress' ).find( '.progress-bar' ).find( '.sr-only' ).html( progress + '% Complete' );"
									.			"beginInstallStep( nextstep );"
									.		"};"
									.		"function beginInstallStep( step ) {"
									.			"if ( step in packages ) {"
									.				"packages[step]();"
									.			"}"
									.		"};"
									.		"beginInstallStep( 0 );";
		} else {
			$js						.=		"$.ajax({"
									.			"url: '" . addslashes( $uninstallUrl ) . "',"
									.			"cache: false,"
									.			"type: 'GET',"
									.			"beforeSend: function( jqXHR, settings ) {"
									.				"$( '#packageinstaller-package' ).html( 'Nothing to install. Cleaning up...' );"
									.				"$( '#packageinstaller-log' ).append( '<div>Installer is cleaning up.</div>' );"
									.				"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.cleanup.begin', [jqXHR, settings] );"
									.			"},"
									.			"complete: function( jqXHR, textStatus ) {"
									.				"$( '#packageinstaller-progress' ).find( '.progress-bar' ).attr( 'aria-valuenow', 100 ).css( 'width', '100%' );"
									.				"$( '#packageinstaller-progress' ).find( '.progress-bar' ).find( '.sr-only' ).html( '100% Complete' );"
									.				"$( '#packageinstaller-progress' ).removeClass( 'progress-striped active' );"
									.				"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.install.done' );"
									.			"},"
									.			"success: function( data, textStatus, jqXHR ) {"
									.				"var msg = data.replace( /^TRUE|TRUE:|FALSE|FALSE:/i, '' );"
									.				"var messages = '';"
									.				"if ( ( typeof msg != 'undefined' ) && ( msg != '' ) ) {"
									.					"try {"
									.						"$.each( $.parseJSON( msg ), function() {"
									.							"if ( this.type == 'notice' ) {"
									.								"this.type = 'info';"
									.							"} else if ( this.type == 'message' ) {"
									.								"this.type = 'sccess';"
									.							"}"
									.							"messages += '<div class=\"alert alert-' + this.type + '\">' + this.message + '</div>';"
									.						"});"
									.					"} catch ( e ) {"
									.						"messages = msg;"
									.					"}"
									.				"}"
									.				"if ( data.match( /^TRUE/i ) ) {"
									.					"$( '.packageinstaller-installer' ).replaceWith( '<div class=\"alert alert-danger\">Nothing to install.</div>' );"
									.				"} else {"
									.					"$( '#packageinstaller-package' ).html( 'The Package Installer failed to clean up. Please uninstall the Package Installer manually within " . ( $this->plugin ? 'Community Builder > Plugin Management' : 'Extensions > Manage' ) . ".' );"
									.					"$( '#packageinstaller-log' ).append( '<div class=\"text-danger\">Installer failed to clean up!' + ( messages ? ' <small><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsShow\">show</a><a href=\"javascript: void(0);\" class=\"packageInstallerAlertsHide\" style=\"display: none;\">hide</a></small><div class=\"packageInstallerAlerts\" style=\"display: none;\">' + messages + '</div>' : '' ) + '</div>' );"
									.					"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.cleanup.failed', [data, textStatus, jqXHR] );"
									.				"}"
									.			"},"
									.			"error: function( jqXHR, textStatus, errorThrown ) {"
									.				"$( '#packageinstaller-package' ).html( 'The Package Installer failed to clean up. Please uninstall the Package Installer manually within " . ( $this->plugin ? 'Community Builder > Plugin Management' : 'Extensions > Manage' ) . ".' );"
									.				"$( '#packageinstaller-log' ).append( '<div class=\"text-danger\">Installer failed to clean up! Error: ' + jqXHR.status + ' - ' + errorThrown + '</div>' );"
									.				"$( '.cb_packageinstaller' ).triggerHandler( 'cbpackagebuilder.cleanup.failed', [jqXHR, textStatus, errorThrown] );"
									.			"}"
									.		"});";
		}

		if ( $this->plugin ) {
			$_CB_framework->outputCbJQuery( $js );
		} else {
			$js						.=	"});";

			$return					.=		'<script type="text/javascript">' . $js . '</script>';
		}

		$return						.=	'</div>';

		echo $return;

		return true;
	}

	/**
	 * Parses for package type files with Joomla version dependency check
	 *
	 * @param string $type
	 * @param array  $packages
	 * @param int    $count
	 * @param null   $subDir
	 */
	private function directory_files( $type, &$packages, &$count = 0, $subDir = null )
	{
		global $_PLUGINS;

		if ( $this->plugin ) {
			$extensionDir								=	$_PLUGINS->getPluginPath( $this->plugin ) . '/extensions/' . $type . '/' . $subDir;
		} else {
			$extensionDir								=	JPATH_ADMINISTRATOR . '/components/com_packageinstaller/extensions/' . $type . '/' . $subDir;
		}

		if ( is_dir( $extensionDir ) ) {
			$files										=	scandir( $extensionDir );

			if ( $files ) {
				foreach ( $files as $file ) {
					if ( ( $file != '.' ) && ( $file != '..' ) && ( $file != 'index.html' ) ) {
						if ( is_dir( $extensionDir . $file ) ) {
							$this->directory_files( $type, $packages, $count, $subDir . $file . '/' );
						} else {
							$package					=	null;

							switch ( $type ) {
								case 'scripts':
									if ( preg_match( '/^([\w-+.]+)\.php$/', $file ) ) {
										$package		=	$file;
									}
									break;
								case 'queries':
									if ( preg_match( '/^([\w-+.]+)\.(sql|txt)$/', $file ) ) {
										$package		=	$file;
									}
									break;
								default:
									if ( preg_match( '/^([\w-+.]+)\.zip$/', $file ) ) {
										$package		=	$file;
									}
									break;
							}

							if ( $package ) {
								$include				=	true;
								$jVersion				=	$this->jVersion();

								if ( $subDir ) {
									$folderCMS			=	preg_match( '%^j((\d)\.?(\d))/%', $subDir, $matches );

									if ( $folderCMS ) {
										$folderVersion	=	$this->jVersion( $matches[2] . '.' . $matches[3] );

										if ( $jVersion < $folderVersion ) {
											$include	=	false;
										}
									}
								}

								if ( $include ) {
									$packageCMS			=	preg_match( '/j((\d)\.?(\d))/', $package, $matches );

									if ( $packageCMS ) {
										$packageVersion	=	$this->jVersion( $matches[2] . '.' . $matches[3] );

										if ( $jVersion < $packageVersion ) {
											$include	=	false;
										}
									}
								}

								if ( $include ) {
									$count				+=	1;
									$packages[$type][]	=	$subDir . $package;
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Returns Joomla version
	 *
	 * @param string $v
	 * @return int
	 */
	private function jVersion( $v = null )
	{
		static $cache		=	array();

		if ( ! $v ) {
			$v				=	'joomla';
		}

		if ( ! isset( $cache[$v] ) ) {
			if ( $v != 'joomla' ) {
				$release	=	substr( $v, 0, 3 );
			} else {
				$version	=	new JVersion();
				$release	=	substr( $version->RELEASE, 0, 3 );
			}

			if ( strcasecmp( $release, '3.0' ) >= 0 ) {
				$cache[$v]	=	5;
			} elseif ( strcasecmp( $release, '2.5' ) >= 0 ) {
				$cache[$v]	=	4;
			} elseif ( strcasecmp( $release, '1.7' ) >= 0 ) {
				$cache[$v]	=	3;
			} elseif ( strcasecmp( $release, '1.6' ) >= 0 ) {
				$cache[$v]	=	2;
			} else {
				$cache[$v]	=	1;
			}
		}

		return $cache[$v];
	}
}